#!/usr/bin/sh

qvm-features-request supported-feature.keyboard-layout=1
