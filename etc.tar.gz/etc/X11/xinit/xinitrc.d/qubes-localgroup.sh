#!/usr/bin/sh

[ -x /usr/bin/xhost ] && xhost +si:localgroup:qubes >& /dev/null
